# -*- coding: utf-8 -*-
"""Point d'entrée de BarkaPaie_RH (fenêtre de bureau)."""
import os
import sys
import traceback

ICI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ICI)
os.environ["BARKAPAIE_DESKTOP"] = "1"

import fenetre  # noqa: E402

try:
    import db  # noqa: E402
    import app  # noqa: E402
    fenetre.lancer(app.app, "BarkaPaie_RH", db.DATA_DIR, "BarkaPaie_RH_instance")
except Exception:
    detail = traceback.format_exc()
    try:
        dossier = os.environ.get("BARKAPAIE_DATA") or os.path.join(fenetre.dossier_documents(), "BarkaPaie_RH")
        os.makedirs(dossier, exist_ok=True)
        with open(os.path.join(dossier, "erreur_demarrage.txt"), "w", encoding="utf-8") as fh:
            fh.write(detail)
    except OSError:
        pass
    fenetre.message("BarkaPaie_RH", "Le logiciel n'a pas pu démarrer.\n\n" + detail[-900:], erreur=True)
